/*
 * Convert Life pattern from .RLE format to text format
 * Implemented in Borland C 3.1 for MS-DOS
 * (This should be easily convertible to other platforms)
 *
 * By Mark D. Niemiec 1997
 * E-mail:  mniemiec@interserv.com
 * WWW:  http://home.sprynet.com/interserv/mniemiec/lifepage.htm
 */
#include <stdio.h>		// ferror fopen fprintf getc putc sprintf ungetc
#include <stdlib.h>		// exit
#include <string.h>		// strcat strlen strncpy strnicmp



/*
 * Global variables
 */
char	outputChars[6] = ".OXYZ\0"; /* dead state, 5 living states */



/*
 * .RLE files are ASCII text files with a one-line header,
 * and followed by a variable-length run-length encoded image.
 *
 * The header may be preceded by any number of blank lines and/or
 * comment lines beginning with a pound sign '#'.
 *
 * The header consists of several fields separated by commas,
 * and ending in a newline.
 * The first two fields are "x = nnn" and "y = nnn", (where nnn
 * is an integer) respectively specifying the pattern width and height.
 * These fields are required.
 *
 * An optional rule field, of the form "rule = Bnnn/Snnn" may follow,
 * encoding totalistic rules.  By convention, this field is required
 * a rule different from Life (B3/S23) is used.
 *
 * The data portion consists of one or more runs, terminated by
 * an exclamation mark '!'.
 * The runs are defined by a single character, preceded by an optional
 * integer repeat factor (which defaults to 1 if omitted).
 * The character may be one of the following:
 *	$	Newline
 *	b	Dead cell
 *	o	Living cell, or first living state in multi-state Life
 *	x*	Second living state in multi-state Life
 *	y*	Third living state in multi-state Life
 *	z*	Fourth living state in multi-state Life
 *	other	Unrecognized codes should be interpreted as living cells
 * (NOTE: characters marked * above are extensions used by this program,
 *  but not part of the generally accepted de-facto RLE standard;
 *  however, x, y, and z behave correctly when treated as 'other')
 * Embedded white space is ignored.
 *
 * The de-facto RLE standard adds the following additional stipulations:
 * Lines should not exceed 70 characters to avoid confusing brain-damaged
 * e-mail programs, so newlines should be added as required.
 * Newlines and other white-space may not be inserted in the middle of a
 * repeat factor, nor between a character and its repeat factor.
 * This program can, however, read files which violate these stipulations.
 *
 * This program can also read .RLE files without headers,
 * since it does not use the header information for anything.
 */



/*
 * Read .RLE-format file
 */
void
ReadRle (FILE *srcFile, FILE *dstFile)
{
	int		repl;		/* replication count */
	int		ifrepl;		/* is replication count given? */
	int		c;		/* character read from file */
	int		curx;		/* x coordinate being written */
	int		cury;		/* y coordinate being written */

	for (;;) {			/* strip leading comment lines: */
		switch ((c = getc (srcFile))) {
		case EOF:			/* end of file: no comment */
			break;
		case '\n':			/* blank line: ignored */
			continue;
		case '#':			/* #: comment line */
			while ((c = getc (srcFile)) != '\n') {
				if (c == EOF)	/* EOF in comment!?! */
					break;
			}
			continue;
		default:			/* other: legitimate text */
			ungetc (c, srcFile);
			break;
		}
		break;
	}

	while ((c = getc(srcFile)) == ' ' || c == '\t' || c == '\n');
	if (c == 'x') {			/* header line is supplied (and ignored) */
		while ((c = getc(srcFile)) != EOF && c != '\n');
	} else {			/* no header: translator doesn't care */
		ungetc (c, srcFile);
	}

	for (repl = 1, ifrepl = 0, curx = cury = 0; ; ) {
		while ((c = getc (srcFile)) == ' ' || c == '\t' || c == '\n');
		switch (c) {
		default:
			if (c >= '0' && c <= '9') {
				repl = (ifrepl ? 10*repl : 0) + (c-'0');
				ifrepl = 1;
				continue;
			} else {
				outputChars[5] = c;
				c = 5;
				break;
			}
		case EOF:
			fprintf (stderr, "Missing end-of-file '!' mark\n");
		case '!':
			if (curx != 0)		/* ALWAYS flush last line */
				fprintf (dstFile, "\n");
			return;
		case 'b':
			c = 0;
			break;
		case 'o':
			c = 1;
			break;
		case 'x':
			c = 2;
			break;
		case 'y':
			c = 3;
			break;
		case 'z':
			c = 4;
			break;
		case '$':
			for (; repl > 0; ++cury, --repl, curx = 0)
				fprintf (dstFile, "\n");
			continue;
		}

		for (c = outputChars[c]; repl > 0; ++curx, --repl)
			putc (c, dstFile);

		repl = 1;
		ifrepl = 0;
	}
}



/*
 * Main
 */
void
main (int argc, char **argv)
{
	char		*arg;		/* argument being examined */
	FILE		*srcFile;	/* source file */
	FILE		*dstFile;	/* destination file */

	if (argc > 1 && strnicmp (argv[1], "-c", 2) == 0) {
		strncpy (outputChars, argv[1]+2, 5);
		--argc;
		++argv;
	}

	if (argc != 3) {
		fprintf (stderr,
		  "Usage:  RLE2TXT [-C[.[o[x[y[z]]]]]] infile.rle outfile.txt\n");
		exit (1);
	}

	if (outputChars[0] == '\0')
		strcat (outputChars, ".");
	if (outputChars[1] == '\0')
		strcat (outputChars, "*");
	while (strlen (outputChars) < 5) {
		sprintf (outputChars + strlen (outputChars),
		  "%c", outputChars[1]);
	}

	if ((srcFile = fopen (argv[1], "r")) == NULL) {
		fprintf (stderr, "Cannot open %s\n", argv[1]);
		exit (1);
	}

	if ((dstFile = fopen (argv[2], "w")) == NULL) {
		fprintf (stderr, "Cannot create %s\n", argv[2]);
		exit (1);
	}

	ReadRle (srcFile, dstFile);

	if (ferror (dstFile)) {
		fprintf (stderr, "Disk full writing to %s\n", argv[2]);
		exit (1);
	}

	exit (0);
}
